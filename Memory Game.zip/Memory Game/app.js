const cardArray = [
    {
        name: 'Ironman',
        img: 'img/iron.jpg',
    },
    {
        name: 'Captain',
        img: 'img/capt.jpg',
    },
    {
        name: 'Panther',
        img: 'img/panther.jpg',
    },
    {
        name: 'Justice',
        img: 'img/jl.jpg',
    },
    {
        name: 'Irondark',
        img: 'img/desk.jpg',
    },
    {
        name: 'Batman',
        img: 'img/bat.jpg',
    },
    {
        name: 'Ironman',
        img: 'img/iron.jpg',
    },
    {
        name: 'Captain',
        img: 'img/capt.jpg',
    },
    {
        name: 'Panther',
        img: 'img/panther.jpg',
    },
    {
        name: 'Justice',
        img: 'img/jl.jpg',
    },
    {
        name: 'Irondark',
        img: 'img/desk.jpg',
    },
    {
        name: 'Batman',
        img: 'img/bat.jpg',
    }, 
]

cardArray.sort(() => 0.5 - Math.random()) //shortcut for shuffling an array randomly

const gridDisplay = document.querySelector('#grid')
const resultsDisplay = document.querySelector('#result')
let cardsChosen = []
let cardsChosenIds = []
const cardsWon = []
function createBoard (){
    for(let i = 0 ; i < cardArray.length ; i++){
        const card = document.createElement('img')
        card.setAttribute('src', 'img/blank.jpg')
        card.setAttribute('data-id',i)
        card.addEventListener('click', flipCard)
        gridDisplay.appendChild(card)
    }
}
createBoard()
function checkMatch(){
    const cards = document.querySelectorAll('img')
    const optionOneId = cardsChosenIds[0]
    const optionTwoId = cardsChosenIds[1]
    console.log(cards)
    console.log('check for a match!')

    if(optionOneId == optionTwoId){
        cards[optionOneId].setAttribute('src','img/blank.jpg')
        cards[optionTwoId].setAttribute('src','img/blank.jpg')

        alert('You have clicked the same image!')

    }
    if (cardsChosen[0] == cardsChosen[1]){
        alert('You found a match!')
        cards[optionOneId].setAttribute('src','img/spider.jpg')
        cards[optionTwoId].setAttribute('src','img/spider.jpg')
        cards[optionOneId].removeEventListener('click', flipCard)
        cards[optionTwoId].removeEventListener('click', flipCard)
        cardsWon.push(cardsChosen)
    }else{
        cards[optionOneId].setAttribute('src','img/blank.jpg')
        cards[optionTwoId].setAttribute('src','img/blank.jpg')
        alert('Sorry , try again!')
        
    }
    resultsDisplay.textContent = cardsWon.length

    cardsChosen = []
    cardsChosenIds = []
    if(cardsWon.length == cardArray.length/2){
      resultsDisplay.textContent = 'Congratulations, you found them all'

    }
}

function flipCard(){
   
const cardId = this.getAttribute('data-id')

cardsChosen.push(cardArray[cardId].name)
cardsChosenIds.push(cardId)
console.log(cardsChosen)
console.log(cardsChosenIds)
this.setAttribute('src',cardArray[cardId].img)
if(cardsChosen.length ===2){

    setTimeout(checkMatch, 500)
}
}